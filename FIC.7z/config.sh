sudo setxkbmap es
sudo sed -i 's/XKBLAYOUT=\"\w*"/XKBLAYOUT=\"es\"/g' /etc/default/keyboard
sudo ln -vfns /vagrant/wallpaper/fic.png /usr/share/xfce4/backdrops/xubuntu-wallpaper.png