#!/usr/bin/env bash

apt-get update
apt-get -y upgrade
apt-get install -y aptitude gedit notepadqq emacs vim octave maven virtualenv gdb htop bison traceroute ghc elixir erlang 
snap install --classic code
snap install --classic gitkraken
snap install postgresql-client